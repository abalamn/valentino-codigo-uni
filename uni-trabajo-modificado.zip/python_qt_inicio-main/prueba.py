import sys
import sqlite3
import re
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QGridLayout, QMessageBox
from PyQt5.QtGui import QPalette, QBrush, QPixmap, QCursor

# Crear base de datos
def crear_db():
    conn = sqlite3.connect('usuarios.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY,
            correo TEXT NOT NULL UNIQUE,
            dni TEXT NOT NULL,
            contraseña TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Validar correo
def validar_correo(correo):
    return re.match(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$', correo)

class VentanaRegistro(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Registro de Usuario')
        self.setGeometry(100, 100, 300, 200)
        self.fondo2_imagen("fondo2.jpg")

        self.layout = QGridLayout()

        # Etiquetas
        label_correo = QLabel('Correo:')
        label_correo.setStyleSheet("color: #FFD700;")  # Amarillo claro
        self.layout.addWidget(label_correo, 0, 0)
        
        label_dni = QLabel('DNI:')
        label_dni.setStyleSheet("color: #FFD700;")  # Amarillo claro
        self.layout.addWidget(label_dni, 1, 0)

        label_pass = QLabel('Contraseña:')
        label_pass.setStyleSheet("color: #FFD700;")  # Amarillo claro
        self.layout.addWidget(label_pass, 2, 0)

        # Entradas
        self.entrada_correo = QLineEdit()
        self.entrada_correo.setStyleSheet("background-color: transparent; border: 1px solid red; color: white;")
        self.layout.addWidget(self.entrada_correo, 0, 1)

        self.entrada_dni = QLineEdit()
        self.entrada_dni.setStyleSheet("background-color: transparent; border: 1px solid red; color: white;")
        self.layout.addWidget(self.entrada_dni, 1, 1)

        self.entrada_pass = QLineEdit()
        self.entrada_pass.setEchoMode(QLineEdit.Password)
        self.entrada_pass.setStyleSheet("background-color: transparent; border: 1px solid red; color: white;")
        self.layout.addWidget(self.entrada_pass, 2, 1)

        # Botón registrar
        self.boton_registrar = QPushButton('Registrar')
        self.layout.addWidget(self.boton_registrar, 3, 0, 1, 2)
        self.boton_registrar.clicked.connect(self.registrar_usuario)

        self.setLayout(self.layout)

    def fondo2_imagen(self, ruta):
        oImage = QPixmap(ruta)
        sImage = oImage.scaled(self.size(), 1)
        palette = QPalette()
        palette.setBrush(QPalette.Background, QBrush(sImage))
        self.setPalette(palette)

    def registrar_usuario(self):
        correo = self.entrada_correo.text()
        dni = self.entrada_dni.text()
        contraseña = self.entrada_pass.text()

        if not validar_correo(correo):
            QMessageBox.warning(self, 'Error', 'Correo no válido')
            return

        conn = sqlite3.connect('usuarios.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM usuarios WHERE correo=?', (correo,))
        if cursor.fetchone():
            QMessageBox.warning(self, 'Error', 'Correo ya registrado')
        else:
            cursor.execute('INSERT INTO usuarios (correo, dni, contraseña) VALUES (?, ?, ?)', (correo, dni, contraseña))
            conn.commit()
            QMessageBox.information(self, 'Éxito', 'Usuario registrado')
            self.close()

        conn.close()

class VentanaLogin(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Iniciar Sesión')
        self.setGeometry(100, 100, 300, 150)
        self.fondo_imagen("fondo.jpg")

        self.layout = QGridLayout()

        # Etiquetas
        label_correo = QLabel('Correo:')
        label_correo.setStyleSheet("color: #FFD700;")  # Amarillo claro
        self.layout.addWidget(label_correo, 0, 0)

        label_dni = QLabel('DNI:')
        label_dni.setStyleSheet("color: #FFD700;")  # Amarillo claro
        self.layout.addWidget(label_dni, 1, 0)

        # Entradas
        self.entrada_correo = QLineEdit()
        self.entrada_correo.setStyleSheet("background-color: transparent; border: 1px solid red; color: white;")
        self.layout.addWidget(self.entrada_correo, 0, 1)

        self.entrada_dni = QLineEdit()
        self.entrada_dni.setStyleSheet("background-color: transparent; border: 1px solid red; color: white;")
        self.layout.addWidget(self.entrada_dni, 1, 1)

        # Botones
        self.boton_login = QPushButton('Iniciar Sesión')
        self.layout.addWidget(self.boton_login, 2, 0, 1, 2)
        self.boton_login.clicked.connect(self.verificar_credenciales)

        self.boton_registrar = QPushButton('Registrar')
        self.layout.addWidget(self.boton_registrar, 3, 0, 1, 2)
        self.boton_registrar.clicked.connect(self.abrir_registro)

        self.setLayout(self.layout)

    def fondo_imagen(self, ruta):
        oImage = QPixmap(ruta)
        sImage = oImage.scaled(self.size(), 1)
        palette = QPalette()
        palette.setBrush(QPalette.Background, QBrush(sImage))
        self.setPalette(palette)

    def verificar_credenciales(self):
        correo = self.entrada_correo.text()
        dni = self.entrada_dni.text()

        conn = sqlite3.connect('usuarios.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM usuarios WHERE correo=? AND dni=?', (correo, dni))
        if cursor.fetchone():
            QMessageBox.information(self, 'Éxito', f'Bienvenido, {correo}!')
            self.close()
        else:
            QMessageBox.warning(self, 'Error', 'Credenciales incorrectas')

        conn.close()

    def abrir_registro(self):
        self.ventana_registro = VentanaRegistro()
        self.ventana_registro.show()

def main():
    app = QApplication(sys.argv)
    app.setOverrideCursor(QCursor(QPixmap("cursor.png")))
    crear_db()
    ventana_login = VentanaLogin()
    ventana_login.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
